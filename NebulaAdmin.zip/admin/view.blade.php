@extends('layouts.admin')
@section('title', 'NebulaAdmin - Admin Panel')

@section('content-header')
@endsection

@section('content')
<div id="nebula-wrap">
    <div class="nb-shell">
        <!-- Sidebar -->
        <aside class="nb-sidebar">
            <a href="{{ $root }}" class="nb-logo">
                <div class="nb-logo-icon"><i class="fa fa-space-shuttle"></i></div>
                <div class="nb-logo-text">Nebula<span>Admin</span></div>
            </a>

            <nav class="nb-nav">
                <div class="nb-nav-section">
                    <div class="nb-nav-label">General</div>
                    <a href="{{ $root }}?section=dashboard" class="nb-nav-item {{ $section == 'dashboard' ? 'active' : '' }}">
                        <i class="fa fa-th-large"></i> Dashboard
                    </a>
                    <a href="{{ $root }}?section=settings" class="nb-nav-item {{ $section == 'settings' ? 'active' : '' }}">
                        <i class="fa fa-cog"></i> Settings
                    </a>
                </div>

                <div class="nb-nav-section">
                    <div class="nb-nav-label">Management</div>
                    <a href="{{ $root }}?section=servers" class="nb-nav-item {{ $section == 'servers' ? 'active' : '' }}">
                        <i class="fa fa-server"></i> Servers
                    </a>
                    <a href="{{ $root }}?section=users" class="nb-nav-item {{ $section == 'users' ? 'active' : '' }}">
                        <i class="fa fa-users"></i> Users
                    </a>
                    <a href="{{ $root }}?section=nodes" class="nb-nav-item {{ $section == 'nodes' ? 'active' : '' }}">
                        <i class="fa fa-database"></i> Nodes
                    </a>
                    <a href="{{ $root }}?section=eggs" class="nb-nav-item {{ $section == 'eggs' ? 'active' : '' }}">
                        <i class="fa fa-cubes"></i> Eggs & Nests
                    </a>
                    <a href="{{ $root }}?section=databases" class="nb-nav-item {{ $section == 'databases' ? 'active' : '' }}">
                        <i class="fa fa-hdd-o"></i> Databases
                    </a>
                </div>
            </nav>

            <div class="nb-sidebar-footer">
                <a href="/admin/extensions" class="nb-back-link">
                    <i class="fa fa-arrow-left"></i> Back to Extensions
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="nb-main">
            <header class="nb-topbar">
                <div class="nb-page-title">
                    @yield('nb-title', ucfirst($section))
                </div>

                <div class="nb-topbar-actions">
                    @if($section == 'servers' || $section == 'users')
                        <div class="nb-search-wrap">
                            <i class="fa fa-search nb-search-icon"></i>
                            <form action="{{ $root }}" method="GET">
                                <input type="hidden" name="section" value="{{ $section }}">
                                <input type="text" name="q" class="nb-search" placeholder="Search..." value="{{ $search ?? '' }}">
                            </form>
                        </div>
                    @endif
                    <div class="nb-badge purple">v1.0.0</div>
                </div>
            </header>

            <div class="nb-content">
                @if(session('success'))
                    <div class="nb-alert success">
                        <i class="fa fa-check-circle"></i> {{ session('success') }}
                    </div>
                @endif

                @if($section == 'dashboard')
                    @include('admin.extensions.{identifier}.sections.dashboard')
                @elseif($section == 'servers')
                    @include('admin.extensions.{identifier}.sections.servers')
                @elseif($section == 'users')
                    @include('admin.extensions.{identifier}.sections.users')
                @elseif($section == 'nodes')
                    @include('admin.extensions.{identifier}.sections.nodes')
                @elseif($section == 'eggs')
                    @include('admin.extensions.{identifier}.sections.eggs')
                @elseif($section == 'databases')
                    @include('admin.extensions.{identifier}.sections.databases')
                @elseif($section == 'settings')
                    @include('admin.extensions.{identifier}.sections.settings')
                @endif
            </div>
        </main>
    </div>
</div>

<style>
    /* Hide default Pterodactyl admin elements to make it look like a full remake */
    .content-header, .main-sidebar, .main-header { display: none !important; }
    .content-wrapper { margin-left: 0 !important; padding-top: 0 !important; background: var(--nb-bg) !important; border: none !important; }
    .wrapper { background: var(--nb-bg) !important; }
</style>
@endsection
