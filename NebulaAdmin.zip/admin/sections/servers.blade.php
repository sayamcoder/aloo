<div class="nb-filter-bar">
    <a href="{{ $root }}?section=servers&status=all" class="nb-filter-btn {{ $status == 'all' ? 'active' : '' }}">All Servers</a>
    <a href="{{ $root }}?section=servers&status=active" class="nb-filter-btn {{ $status == 'active' ? 'active' : '' }}">Active</a>
    <a href="{{ $root }}?section=servers&status=suspended" class="nb-filter-btn {{ $status == 'suspended' ? 'active' : '' }}">Suspended</a>
</div>

<div class="nb-card">
    <div class="nb-card-body" style="padding: 0;">
        <div class="nb-table-wrap">
            <table class="nb-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Server Name</th>
                        <th>Owner</th>
                        <th>Node</th>
                        <th>Resources</th>
                        <th>Created</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($servers as $server)
                    <tr>
                        <td class="muted">{{ $server->id }}</td>
                        <td>
                            <div style="font-weight: 600;">{{ $server->name }}</div>
                            <div class="nb-uuid">{{ $server->uuid }}</div>
                        </td>
                        <td>
                            <div>{{ $server->owner_name }}</div>
                            <div class="nb-uuid" style="font-size: 0.65rem;">{{ $server->owner_email }}</div>
                        </td>
                        <td>{{ $server->node_name }}</td>
                        <td>
                            <div style="font-size: 0.75rem;">
                                <i class="fa fa-microchip muted"></i> {{ $server->cpu }}% 
                                <i class="fa fa-memory muted" style="margin-left: 8px;"></i> {{ $server->memory }}MB
                            </div>
                        </td>
                        <td class="muted">{{ date('M d, Y', strtotime($server->created_at)) }}</td>
                        <td>
                            @if($server->suspended)
                                <span class="nb-badge red">Suspended</span>
                            @else
                                <span class="nb-badge green">Active</span>
                            @endif
                        </td>
                        <td>
                            <a href="/admin/servers/view/{{ $server->id }}" class="nb-btn nb-btn-secondary nb-btn-sm">
                                <i class="fa fa-external-link"></i>
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="8">
                            <div class="nb-empty">
                                <i class="fa fa-search"></i>
                                <p>No servers found matching your criteria.</p>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

@if($total > $perPage)
<div class="nb-pagination">
    @if($page > 1)
        <a href="{{ $root }}?section=servers&page={{ $page - 1 }}&status={{ $status }}&q={{ $search }}" class="nb-page-btn"><i class="fa fa-chevron-left"></i></a>
    @endif
    <div class="nb-page-info">Page {{ $page }} of {{ ceil($total / $perPage) }}</div>
    @if($page < ceil($total / $perPage))
        <a href="{{ $root }}?section=servers&page={{ $page + 1 }}&status={{ $status }}&q={{ $search }}" class="nb-page-btn"><i class="fa fa-chevron-right"></i></a>
    @endif
</div>
@endif
