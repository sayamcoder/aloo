<!-- Stats Grid -->
<div class="nb-stats-grid">
    <div class="nb-stat-card purple">
        <div class="nb-stat-icon"><i class="fa fa-server"></i></div>
        <div class="nb-stat-value">{{ $stats['totalServers'] }}</div>
        <div class="nb-stat-label">Total Servers</div>
        <div class="nb-stat-sub"><span>{{ $stats['activeServers'] }}</span> active, <span class="red">{{ $stats['suspendedServers'] }}</span> suspended</div>
    </div>
    <div class="nb-stat-card cyan">
        <div class="nb-stat-icon"><i class="fa fa-users"></i></div>
        <div class="nb-stat-value">{{ $stats['totalUsers'] }}</div>
        <div class="nb-stat-label">Total Users</div>
        <div class="nb-stat-sub"><span>+{{ $stats['recentSignups'] }}</span> new this week</div>
    </div>
    <div class="nb-stat-card green">
        <div class="nb-stat-icon"><i class="fa fa-microchip"></i></div>
        <div class="nb-stat-value">{{ $stats['totalNodes'] }}</div>
        <div class="nb-stat-label">Total Nodes</div>
        <div class="nb-stat-sub">{{ $stats['totalAllocations'] }} allocations total</div>
    </div>
    <div class="nb-stat-card yellow">
        <div class="nb-stat-icon"><i class="fa fa-hdd-o"></i></div>
        <div class="nb-stat-value">{{ $stats['totalDatabases'] }}</div>
        <div class="nb-stat-label">Databases</div>
        <div class="nb-stat-sub">Managed across all hosts</div>
    </div>
</div>

<div class="nb-grid-2">
    <!-- Recent Servers -->
    <div class="nb-card">
        <div class="nb-card-header">
            <div class="nb-card-title"><i class="fa fa-clock-o"></i> Recent Servers</div>
            <a href="{{ $root }}?section=servers" class="nb-btn nb-btn-secondary nb-btn-sm">View All</a>
        </div>
        <div class="nb-card-body">
            <div class="nb-table-wrap">
                <table class="nb-table">
                    <thead>
                        <tr>
                            <th>Server</th>
                            <th>Owner</th>
                            <th>Node</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($recentServers as $server)
                        <tr>
                            <td>
                                <div style="font-weight: 600;">{{ $server->name }}</div>
                                <div class="nb-uuid">{{ $server->uuid }}</div>
                            </td>
                            <td>{{ $server->owner_name }}</td>
                            <td class="muted">{{ $server->node_name }}</td>
                            <td>
                                @if($server->suspended)
                                    <span class="nb-badge red">Suspended</span>
                                @else
                                    <span class="nb-badge green">Active</span>
                                @endif
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Node Usage -->
    <div class="nb-card">
        <div class="nb-card-header">
            <div class="nb-card-title"><i class="fa fa-tasks"></i> Node Resource Usage</div>
            <a href="{{ $root }}?section=nodes" class="nb-btn nb-btn-secondary nb-btn-sm">Nodes</a>
        </div>
        <div class="nb-card-body">
            @foreach($nodes->take(4) as $node)
            <div class="nb-node-card">
                <div class="nb-node-header">
                    <div>
                        <div class="nb-node-name">{{ $node->name }}</div>
                        <div class="nb-node-fqdn">{{ $node->fqdn }}</div>
                    </div>
                    <div class="nb-badge {{ $node->mem_pct > 90 ? 'red' : ($node->mem_pct > 70 ? 'yellow' : 'purple') }}">
                        {{ $node->mem_pct }}% Mem
                    </div>
                </div>
                <div class="nb-resource-row">
                    <div class="nb-resource-label">
                        <span>Memory</span>
                        <span>{{ round($node->used_memory/1024, 1) }}GB / {{ round($node->memory/1024, 1) }}GB</span>
                    </div>
                    <div class="nb-progress">
                        <div class="nb-progress-fill {{ $node->mem_pct > 90 ? 'red' : ($node->mem_pct > 70 ? 'yellow' : '') }}" style="width: {{ $node->mem_pct }}%"></div>
                    </div>
                </div>
                <div class="nb-resource-row">
                    <div class="nb-resource-label">
                        <span>Disk</span>
                        <span>{{ round($node->used_disk/1024, 1) }}GB / {{ round($node->disk/1024, 1) }}GB</span>
                    </div>
                    <div class="nb-progress">
                        <div class="nb-progress-fill cyan" style="width: {{ $node->disk_pct }}%"></div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>
