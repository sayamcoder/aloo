<form action="{{ $root }}/settings" method="POST">
    @csrf
    <div class="nb-grid-2">
        <div class="nb-card">
            <div class="nb-card-header">
                <div class="nb-card-title"><i class="fa fa-sliders"></i> Panel Settings</div>
            </div>
            <div class="nb-card-body">
                <div class="nb-form-group">
                    <label>Panel Name</label>
                    <input type="text" name="panel_name" class="nb-input" value="{{ $settings['panel_name'] }}">
                    <span class="hint">The name shown in browser tabs and emails.</span>
                </div>

                <div class="nb-toggle-row">
                    <div class="nb-toggle-label">
                        <strong>Maintenance Mode</strong>
                        <span>Only admins will be able to access the panel.</span>
                    </div>
                    <label class="nb-switch">
                        <input type="checkbox" name="maintenance_mode" value="1" {{ $settings['maintenance_mode'] == '1' ? 'checked' : '' }}>
                        <span class="nb-slider"></span>
                    </label>
                </div>

                <div class="nb-toggle-row">
                    <div class="nb-toggle-label">
                        <strong>Allow User Signups</strong>
                        <span>Whether to allow new users to register on the panel.</span>
                    </div>
                    <label class="nb-switch">
                        <input type="checkbox" name="allow_signups" value="1" {{ $settings['allow_signups'] == '1' ? 'checked' : '' }}>
                        <span class="nb-slider"></span>
                    </label>
                </div>

                <div class="nb-toggle-row">
                    <div class="nb-toggle-label">
                        <strong>Google reCAPTCHA</strong>
                        <span>Enable bot protection on login/signup pages.</span>
                    </div>
                    <label class="nb-switch">
                        <input type="checkbox" name="recaptcha" value="1" {{ $settings['recaptcha'] == '1' ? 'checked' : '' }}>
                        <span class="nb-slider"></span>
                    </label>
                </div>
            </div>
        </div>

        <div class="nb-card">
            <div class="nb-card-header">
                <div class="nb-card-title"><i class="fa fa-envelope-o"></i> Mail Configuration</div>
            </div>
            <div class="nb-card-body">
                <div class="nb-form-group">
                    <label>SMTP Host</label>
                    <input type="text" name="smtp_host" class="nb-input" value="{{ $settings['smtp_host'] }}" placeholder="smtp.mailtrap.io">
                </div>
                <div class="nb-form-grid-2">
                    <div class="nb-form-group">
                        <label>SMTP Port</label>
                        <input type="number" name="smtp_port" class="nb-input" value="{{ $settings['smtp_port'] }}">
                    </div>
                    <div class="nb-form-group">
                        <label>SMTP User</label>
                        <input type="text" name="smtp_user" class="nb-input" value="{{ $settings['smtp_user'] }}">
                    </div>
                </div>
                <div class="nb-form-group">
                    <label>Max Servers Per User</label>
                    <input type="number" name="max_servers_user" class="nb-input" value="{{ $settings['max_servers_user'] }}" placeholder="Leave blank for unlimited">
                </div>
            </div>
        </div>
    </div>

    <div class="nb-card">
        <div class="nb-card-header">
            <div class="nb-card-title"><i class="fa fa-paint-brush"></i> Appearance & Branding</div>
        </div>
        <div class="nb-card-body">
            <div class="nb-form-group">
                <label>Custom Admin CSS</label>
                <textarea name="custom_css" class="nb-textarea" placeholder=".nb-accent { color: red; }">{{ $settings['custom_css'] }}</textarea>
                <span class="hint">Override NebulaAdmin styles with your own CSS.</span>
            </div>
            <div class="nb-form-group">
                <label>Panel Footer Text</label>
                <input type="text" name="custom_footer" class="nb-input" value="{{ $settings['custom_footer'] }}" placeholder="&copy; 2025 NebulaPanel">
            </div>
        </div>
    </div>

    <div style="display: flex; justify-content: flex-end;">
        <button type="submit" class="nb-btn nb-btn-primary">
            <i class="fa fa-save"></i> Save Settings
        </button>
    </div>
</form>
