<div class="nb-filter-bar">
    <a href="{{ $root }}?section=users&role=all" class="nb-filter-btn {{ $role == 'all' ? 'active' : '' }}">All Users</a>
    <a href="{{ $root }}?section=users&role=admin" class="nb-filter-btn {{ $role == 'admin' ? 'active' : '' }}">Admins</a>
    <a href="{{ $root }}?section=users&role=user" class="nb-filter-btn {{ $role == 'user' ? 'active' : '' }}">Standard Users</a>
</div>

<div class="nb-card">
    <div class="nb-card-body" style="padding: 0;">
        <div class="nb-table-wrap">
            <table class="nb-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Role</th>
                        <th>2FA</th>
                        <th>Servers</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($users as $user)
                    <tr>
                        <td class="muted">{{ $user->id }}</td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <div style="width: 32px; height: 32px; border-radius: 50%; background: var(--nb-surface2); display: flex; align-items: center; justify-content: center; border: 1px solid var(--nb-border);">
                                    <i class="fa fa-user muted"></i>
                                </div>
                                <div>
                                    <div style="font-weight: 600;">{{ $user->username }}</div>
                                    <div class="nb-uuid" style="font-size: 0.65rem;">{{ $user->email }}</div>
                                </div>
                            </div>
                        </td>
                        <td>
                            @if($user->root_admin)
                                <span class="nb-badge purple">Administrator</span>
                            @else
                                <span class="nb-badge gray">User</span>
                            @endif
                        </td>
                        <td>
                            @if($user->use_totp)
                                <span class="nb-badge green">Enabled</span>
                            @else
                                <span class="nb-badge red">Disabled</span>
                            @endif
                        </td>
                        <td class="muted">{{ $user->server_count }} servers</td>
                        <td class="muted">{{ date('M d, Y', strtotime($user->created_at)) }}</td>
                        <td>
                            <a href="/admin/users/view/{{ $user->id }}" class="nb-btn nb-btn-secondary nb-btn-sm">
                                <i class="fa fa-edit"></i>
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7">
                            <div class="nb-empty">
                                <i class="fa fa-users"></i>
                                <p>No users found matching your search.</p>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

@if($total > $perPage)
<div class="nb-pagination">
    @if($page > 1)
        <a href="{{ $root }}?section=users&page={{ $page - 1 }}&role={{ $role }}&q={{ $search }}" class="nb-page-btn"><i class="fa fa-chevron-left"></i></a>
    @endif
    <div class="nb-page-info">Page {{ $page }} of {{ ceil($total / $perPage) }}</div>
    @if($page < ceil($total / $perPage))
        <a href="{{ $root }}?section=users&page={{ $page + 1 }}&role={{ $role }}&q={{ $search }}" class="nb-page-btn"><i class="fa fa-chevron-right"></i></a>
    @endif
</div>
@endif
