<div style="display: flex; justify-content: flex-end; margin-bottom: 20px;">
    <a href="/admin/nodes/new" class="nb-btn nb-btn-primary">
        <i class="fa fa-plus"></i> Create Node
    </a>
</div>

<div class="nb-grid-2">
    @foreach($nodes as $node)
    <div class="nb-card">
        <div class="nb-card-header">
            <div class="nb-card-title">
                <i class="fa fa-database"></i> {{ $node->name }}
            </div>
            <div class="nb-badge {{ $node->scheme == 'https' ? 'green' : 'yellow' }}">{{ strtoupper($node->scheme) }}</div>
        </div>
        <div class="nb-card-body">
            <div style="margin-bottom: 15px;">
                <code style="background: var(--nb-surface2); padding: 4px 8px; border-radius: 4px; color: var(--nb-accent2); font-size: 0.85rem;">{{ $node->fqdn }}</code>
            </div>

            <div class="nb-node-meta">
                <span><strong>{{ $node->server_count }}</strong> Servers</span>
                <span><strong>{{ $node->allocations_used }} / {{ $node->allocations_total }}</strong> Allocations</span>
            </div>

            <div class="nb-resource-row">
                <div class="nb-resource-label">
                    <span>Memory Usage ({{ $node->mem_pct }}%)</span>
                    <span>{{ round($node->used_memory/1024, 1) }} / {{ round($node->memory/1024, 1) }} GB</span>
                </div>
                <div class="nb-progress">
                    <div class="nb-progress-fill {{ $node->mem_pct > 90 ? 'red' : ($node->mem_pct > 70 ? 'yellow' : '') }}" style="width: {{ $node->mem_pct }}%"></div>
                </div>
            </div>

            <div class="nb-resource-row" style="margin-top: 12px;">
                <div class="nb-resource-label">
                    <span>Disk Usage ({{ $node->disk_pct }}%)</span>
                    <span>{{ round($node->used_disk/1024, 1) }} / {{ round($node->disk/1024, 1) }} GB</span>
                </div>
                <div class="nb-progress">
                    <div class="nb-progress-fill cyan" style="width: {{ $node->disk_pct }}%"></div>
                </div>
            </div>

            <div style="margin-top: 20px; display: flex; gap: 8px;">
                <a href="/admin/nodes/view/{{ $node->id }}" class="nb-btn nb-btn-secondary nb-btn-sm" style="flex: 1;">Settings</a>
                <a href="/admin/nodes/view/{{ $node->id }}/allocations" class="nb-btn nb-btn-secondary nb-btn-sm" style="flex: 1;">Allocations</a>
            </div>
        </div>
    </div>
    @endforeach
</div>
