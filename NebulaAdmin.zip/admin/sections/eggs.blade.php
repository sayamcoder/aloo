<div class="nb-stats-grid" style="margin-bottom: 20px;">
    <div class="nb-stat-card cyan">
        <div class="nb-stat-icon"><i class="fa fa-cubes"></i></div>
        <div class="nb-stat-value">{{ $nests->count() }}</div>
        <div class="nb-stat-label">Total Nests</div>
    </div>
    <div class="nb-stat-card purple">
        <div class="nb-stat-icon"><i class="fa fa-egg"></i></div>
        <div class="nb-stat-value">{{ $totalEggs }}</div>
        <div class="nb-stat-label">Total Eggs</div>
    </div>
</div>

@foreach($nests as $nest)
<div class="nb-nest-card">
    <div class="nb-nest-header">
        <div class="nb-nest-icon"><i class="fa fa-folder-open"></i></div>
        <div>
            <div class="nb-nest-name">{{ $nest->name }}</div>
            <div style="font-size: 0.75rem; color: var(--nb-muted);">{{ $nest->egg_count }} eggs in this nest</div>
        </div>
        <div style="margin-left: auto;">
            <a href="/admin/nests/view/{{ $nest->id }}" class="nb-btn nb-btn-secondary nb-btn-sm">Configure Nest</a>
        </div>
    </div>
    <div class="nb-egg-grid">
        @foreach($nest->eggs as $egg)
        <a href="/admin/nests/egg/{{ $egg->id }}" class="nb-egg-item" style="text-decoration: none; color: inherit;">
            <div class="nb-egg-name">{{ $egg->name }}</div>
            <div class="nb-egg-desc">{{ $egg->description ?: 'No description provided.' }}</div>
        </a>
        @endforeach
        <a href="/admin/nests/egg/new?nest={{ $nest->id }}" class="nb-egg-item" style="border-style: dashed; display: flex; align-items: center; justify-content: center; min-height: 70px;">
            <i class="fa fa-plus muted" style="margin-right: 8px;"></i>
            <span class="muted" style="font-size: 0.8rem; font-weight: 600;">Add Egg</span>
        </a>
    </div>
</div>
@endforeach
