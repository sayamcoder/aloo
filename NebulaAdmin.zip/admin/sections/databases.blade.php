<div class="nb-card">
    <div class="nb-card-header">
        <div class="nb-card-title"><i class="fa fa-hdd-o"></i> Database Hosts</div>
        <a href="/admin/databases" class="nb-btn nb-btn-primary nb-btn-sm">New Host</a>
    </div>
    <div class="nb-card-body" style="padding: 0;">
        <div class="nb-table-wrap">
            <table class="nb-table">
                <thead>
                    <tr>
                        <th>Host Name</th>
                        <th>Host / IP</th>
                        <th>User</th>
                        <th>Databases</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($databaseHosts as $host)
                    <tr>
                        <td style="font-weight: 600;">{{ $host->name }}</td>
                        <td>
                            <code style="background: var(--nb-surface2); padding: 2px 6px; border-radius: 4px; color: var(--nb-accent2);">{{ $host->host }}:{{ $host->port }}</code>
                        </td>
                        <td class="muted">{{ $host->username }}</td>
                        <td>
                            <span class="nb-badge purple">{{ $host->database_count }} dbs</span>
                        </td>
                        <td>
                            <a href="/admin/databases" class="nb-btn nb-btn-secondary nb-btn-sm">View</a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="nb-card" style="margin-top: 20px;">
    <div class="nb-card-header">
        <div class="nb-card-title"><i class="fa fa-history"></i> Recent Databases</div>
    </div>
    <div class="nb-card-body" style="padding: 0;">
        <div class="nb-table-wrap">
            <table class="nb-table">
                <thead>
                    <tr>
                        <th>Database Name</th>
                        <th>Server</th>
                        <th>Host</th>
                        <th>Created</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($recentDbs as $db)
                    <tr>
                        <td style="font-weight: 600;">{{ $db->database }}</td>
                        <td>{{ $db->server_name }}</td>
                        <td class="muted">{{ $db->host_name }}</td>
                        <td class="muted">{{ date('M d, Y', strtotime($db->created_at)) }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
