<?php

namespace Pterodactyl\Http\Controllers\Admin\Extensions\{identifier};

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\Factory as ViewFactory;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\BlueprintFramework\Libraries\ExtensionLibrary\Admin\BlueprintAdminLibrary as BlueprintExtensionLibrary;

class {identifier}ExtensionController extends Controller
{
    public function __construct(
        private ViewFactory $view,
        private BlueprintExtensionLibrary $blueprint,
    ) {}

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private function getSetting(string $key, mixed $default = ''): mixed
    {
        return DB::table('settings')
            ->where('key', '{identifier}::' . $key)
            ->value('value') ?? $default;
    }

    private function setSetting(string $key, mixed $value): void
    {
        DB::table('settings')->updateOrInsert(
            ['key'   => '{identifier}::' . $key],
            ['value' => (string) $value]
        );
    }

    private function getDashboardStats(): array
    {
        return Cache::remember('nebulaadmin_stats', 30, function () {
            $totalServers  = DB::table('servers')->count();
            $activeServers = DB::table('servers')->where('suspended', 0)->count();
            $totalUsers    = DB::table('users')->count();
            $adminUsers    = DB::table('users')->where('root_admin', 1)->count();
            $totalNodes    = DB::table('nodes')->count();
            $totalEggs     = DB::table('eggs')->count();
            $totalNests    = DB::table('nests')->count();
            $totalAllocations = DB::table('allocations')->count();
            $usedAllocations  = DB::table('allocations')->whereNotNull('server_id')->count();
            $totalDatabases   = DB::table('databases')->count();

            // Memory & disk totals across all nodes
            $nodes = DB::table('nodes')->get(['memory', 'disk', 'memory_overallocate', 'disk_overallocate']);
            $totalMemoryGb = round($nodes->sum('memory') / 1024, 1);
            $totalDiskGb   = round($nodes->sum('disk') / 1024, 1);

            // Servers allocated resources
            $serversResources = DB::table('servers')->get(['memory', 'disk', 'cpu']);
            $usedMemoryGb  = round($serversResources->sum('memory') / 1024, 1);
            $usedDiskGb    = round($serversResources->sum('disk') / 1024, 1);

            // Recent signups (last 7 days)
            $recentSignups = DB::table('users')
                ->where('created_at', '>=', now()->subDays(7))
                ->count();

            // Suspended servers
            $suspendedServers = DB::table('servers')->where('suspended', 1)->count();

            return compact(
                'totalServers', 'activeServers', 'suspendedServers',
                'totalUsers', 'adminUsers', 'recentSignups',
                'totalNodes', 'totalEggs', 'totalNests',
                'totalAllocations', 'usedAllocations',
                'totalDatabases',
                'totalMemoryGb', 'totalDiskGb',
                'usedMemoryGb', 'usedDiskGb'
            );
        });
    }

    // ─── Main Dashboard ───────────────────────────────────────────────────────

    /**
     * Main entry point for the admin page.
     * Routes to different sections based on the 'section' query parameter.
     */
    public function index(Request $request): View
    {
        $section = $request->query('section', 'dashboard');

        return match ($section) {
            'servers'   => $this->servers($request),
            'users'     => $this->users($request),
            'nodes'     => $this->nodes(),
            'eggs'      => $this->eggs(),
            'databases' => $this->databases(),
            'settings'  => $this->settings(),
            default     => $this->dashboard(),
        };
    }

    /**
     * Render the main dashboard.
     */
    public function dashboard(): View
    {
        $stats = $this->getDashboardStats();

        // Recent servers
        $recentServers = DB::table('servers')
            ->join('users', 'servers.owner_id', '=', 'users.id')
            ->join('nodes', 'servers.node_id', '=', 'nodes.id')
            ->select(
                'servers.id', 'servers.uuid', 'servers.name', 'servers.suspended',
                'servers.memory', 'servers.disk', 'servers.cpu',
                'servers.created_at',
                'users.email as owner_email', 'users.username as owner_name',
                'nodes.name as node_name'
            )
            ->orderByDesc('servers.created_at')
            ->limit(8)
            ->get();

        // Recent users
        $recentUsers = DB::table('users')
            ->select('id', 'username', 'email', 'root_admin', 'created_at')
            ->orderByDesc('created_at')
            ->limit(8)
            ->get();

        // Node usage
        $nodes = DB::table('nodes')
            ->select('id', 'name', 'fqdn', 'memory', 'disk', 'memory_overallocate', 'disk_overallocate')
            ->get()
            ->map(function ($node) {
                $used = DB::table('servers')
                    ->where('node_id', $node->id)
                    ->select(DB::raw('SUM(memory) as mem, SUM(disk) as dsk'))
                    ->first();
                $node->used_memory = $used->mem ?? 0;
                $node->used_disk   = $used->dsk ?? 0;
                $node->mem_pct     = $node->memory > 0 ? round(($node->used_memory / $node->memory) * 100) : 0;
                $node->disk_pct    = $node->disk > 0   ? round(($node->used_disk   / $node->disk)   * 100) : 0;
                return $node;
            });

        $settings = [
            'panel_name'       => $this->getSetting('panel_name', 'Pterodactyl Panel'),
            'maintenance_mode' => $this->getSetting('maintenance_mode', '0'),
            'allow_signups'    => $this->getSetting('allow_signups', '1'),
            'recaptcha'        => $this->getSetting('recaptcha', '0'),
        ];

        return $this->view->make(
            'admin.extensions.{identifier}.index',
            [
                'root'          => '/admin/extensions/{identifier}',
                'blueprint'     => $this->blueprint,
                'stats'         => $stats,
                'recentServers' => $recentServers,
                'recentUsers'   => $recentUsers,
                'nodes'         => $nodes,
                'settings'      => $settings,
                'section'       => 'dashboard',
            ]
        );
    }

    // ─── Servers Section ──────────────────────────────────────────────────────

    public function servers(Request $request): View
    {
        $search    = $request->input('q', '');
        $status    = $request->input('status', 'all');
        $perPage   = 20;
        $page      = (int) $request->input('page', 1);

        $query = DB::table('servers')
            ->join('users', 'servers.owner_id', '=', 'users.id')
            ->join('nodes', 'servers.node_id', '=', 'nodes.id')
            ->select(
                'servers.id', 'servers.uuid', 'servers.name', 'servers.suspended',
                'servers.memory', 'servers.disk', 'servers.cpu', 'servers.created_at',
                'users.email as owner_email', 'users.username as owner_name',
                'nodes.name as node_name'
            );

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('servers.name', 'like', "%{$search}%")
                  ->orWhere('users.email', 'like', "%{$search}%")
                  ->orWhere('servers.uuid', 'like', "%{$search}%");
            });
        }

        if ($status === 'active')    $query->where('servers.suspended', 0);
        if ($status === 'suspended') $query->where('servers.suspended', 1);

        $total   = $query->count();
        $servers = $query->orderByDesc('servers.created_at')
                         ->offset(($page - 1) * $perPage)
                         ->limit($perPage)
                         ->get();

        return $this->view->make(
            'admin.extensions.{identifier}.index',
            [
                'root'       => '/admin/extensions/{identifier}',
                'blueprint'  => $this->blueprint,
                'servers'    => $servers,
                'total'      => $total,
                'page'       => $page,
                'perPage'    => $perPage,
                'search'     => $search,
                'status'     => $status,
                'section'    => 'servers',
            ]
        );
    }

    // ─── Users Section ────────────────────────────────────────────────────────

    public function users(Request $request): View
    {
        $search  = $request->input('q', '');
        $role    = $request->input('role', 'all');
        $perPage = 20;
        $page    = (int) $request->input('page', 1);

        $query = DB::table('users')
            ->select('id', 'username', 'email', 'root_admin', 'use_totp', 'created_at');

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('username', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%");
            });
        }

        if ($role === 'admin') $query->where('root_admin', 1);
        if ($role === 'user')  $query->where('root_admin', 0);

        $total = $query->count();
        $users = $query->orderByDesc('created_at')
                       ->offset(($page - 1) * $perPage)
                       ->limit($perPage)
                       ->get()
                       ->map(function ($u) {
                           $u->server_count = DB::table('servers')->where('owner_id', $u->id)->count();
                           return $u;
                       });

        return $this->view->make(
            'admin.extensions.{identifier}.index',
            [
                'root'      => '/admin/extensions/{identifier}',
                'blueprint' => $this->blueprint,
                'users'     => $users,
                'total'     => $total,
                'page'      => $page,
                'perPage'   => $perPage,
                'search'    => $search,
                'role'      => $role,
                'section'   => 'users',
            ]
        );
    }

    // ─── Nodes Section ────────────────────────────────────────────────────────

    public function nodes(): View
    {
        $nodes = DB::table('nodes')
            ->select('id', 'name', 'fqdn', 'scheme', 'memory', 'disk',
                     'memory_overallocate', 'disk_overallocate', 'created_at')
            ->orderBy('name')
            ->get()
            ->map(function ($node) {
                $used = DB::table('servers')
                    ->where('node_id', $node->id)
                    ->select(DB::raw('COUNT(*) as count, SUM(memory) as mem, SUM(disk) as dsk'))
                    ->first();
                $node->server_count = $used->count ?? 0;
                $node->used_memory  = $used->mem ?? 0;
                $node->used_disk    = $used->dsk ?? 0;
                $node->mem_pct      = $node->memory > 0 ? min(100, round(($node->used_memory / $node->memory) * 100)) : 0;
                $node->disk_pct     = $node->disk > 0   ? min(100, round(($node->used_disk   / $node->disk)   * 100)) : 0;
                $node->allocations_total = DB::table('allocations')->where('node_id', $node->id)->count();
                $node->allocations_used  = DB::table('allocations')->where('node_id', $node->id)->whereNotNull('server_id')->count();
                return $node;
            });

        return $this->view->make(
            'admin.extensions.{identifier}.index',
            [
                'root'      => '/admin/extensions/{identifier}',
                'blueprint' => $this->blueprint,
                'nodes'     => $nodes,
                'section'   => 'nodes',
            ]
        );
    }

    // ─── Eggs / Nests Section ─────────────────────────────────────────────────

    public function eggs(): View
    {
        $nests = DB::table('nests')
            ->select('id', 'name', 'description', 'created_at')
            ->orderBy('name')
            ->get()
            ->map(function ($nest) {
                $nest->egg_count = DB::table('eggs')->where('nest_id', $nest->id)->count();
                $nest->eggs = DB::table('eggs')
                    ->where('nest_id', $nest->id)
                    ->select('id', 'name', 'description')
                    ->orderBy('name')
                    ->get();
                return $nest;
            });

        $totalEggs = DB::table('eggs')->count();

        return $this->view->make(
            'admin.extensions.{identifier}.index',
            [
                'root'      => '/admin/extensions/{identifier}',
                'blueprint' => $this->blueprint,
                'nests'     => $nests,
                'totalEggs' => $totalEggs,
                'section'   => 'eggs',
            ]
        );
    }

    // ─── Databases Section ────────────────────────────────────────────────────

    public function databases(): View
    {
        $databaseHosts = DB::table('database_hosts')
            ->select('id', 'name', 'host', 'port', 'username', 'created_at')
            ->orderBy('name')
            ->get()
            ->map(function ($host) {
                $host->database_count = DB::table('databases')->where('database_host_id', $host->id)->count();
                return $host;
            });

        $recentDbs = DB::table('databases')
            ->join('servers', 'databases.server_id', '=', 'servers.id')
            ->join('database_hosts', 'databases.database_host_id', '=', 'database_hosts.id')
            ->select(
                'databases.id', 'databases.database', 'databases.username',
                'databases.created_at',
                'servers.name as server_name',
                'database_hosts.name as host_name'
            )
            ->orderByDesc('databases.created_at')
            ->limit(20)
            ->get();

        return $this->view->make(
            'admin.extensions.{identifier}.index',
            [
                'root'          => '/admin/extensions/{identifier}',
                'blueprint'     => $this->blueprint,
                'databaseHosts' => $databaseHosts,
                'recentDbs'     => $recentDbs,
                'section'       => 'databases',
            ]
        );
    }

    // ─── Settings Section ─────────────────────────────────────────────────────

    public function settings(): View
    {
        $settings = [
            'panel_name'       => $this->getSetting('panel_name', 'Pterodactyl Panel'),
            'maintenance_mode' => $this->getSetting('maintenance_mode', '0'),
            'allow_signups'    => $this->getSetting('allow_signups', '1'),
            'recaptcha'        => $this->getSetting('recaptcha', '0'),
            'custom_css'       => $this->getSetting('custom_css', ''),
            'custom_footer'    => $this->getSetting('custom_footer', ''),
            'max_servers_user' => $this->getSetting('max_servers_user', ''),
            'smtp_host'        => $this->getSetting('smtp_host', ''),
            'smtp_port'        => $this->getSetting('smtp_port', '587'),
            'smtp_user'        => $this->getSetting('smtp_user', ''),
        ];

        return $this->view->make(
            'admin.extensions.{identifier}.index',
            [
                'root'      => '/admin/extensions/{identifier}',
                'blueprint' => $this->blueprint,
                'settings'  => $settings,
                'section'   => 'settings',
            ]
        );
    }

    // ─── Save Settings ────────────────────────────────────────────────────────

    public function saveSettings(Request $request): RedirectResponse
    {
        $request->validate([
            'panel_name'       => 'nullable|string|max:100',
            'maintenance_mode' => 'nullable|string|in:0,1',
            'allow_signups'    => 'nullable|string|in:0,1',
            'recaptcha'        => 'nullable|string|in:0,1',
            'custom_css'       => 'nullable|string|max:10000',
            'custom_footer'    => 'nullable|string|max:500',
            'max_servers_user' => 'nullable|integer|min:0',
            'smtp_host'        => 'nullable|string|max:200',
            'smtp_port'        => 'nullable|integer|min:1|max:65535',
            'smtp_user'        => 'nullable|string|max:200',
        ]);

        $this->setSetting('panel_name',       $request->input('panel_name', 'Pterodactyl Panel'));
        $this->setSetting('maintenance_mode', $request->input('maintenance_mode') === '1' ? '1' : '0');
        $this->setSetting('allow_signups',    $request->input('allow_signups') === '1' ? '1' : '0');
        $this->setSetting('recaptcha',        $request->input('recaptcha') === '1' ? '1' : '0');
        $this->setSetting('custom_css',       $request->input('custom_css', ''));
        $this->setSetting('custom_footer',    $request->input('custom_footer', ''));
        $this->setSetting('max_servers_user', $request->input('max_servers_user', ''));
        $this->setSetting('smtp_host',        $request->input('smtp_host', ''));
        $this->setSetting('smtp_port',        $request->input('smtp_port', '587'));
        $this->setSetting('smtp_user',        $request->input('smtp_user', ''));

        Cache::forget('nebulaadmin_stats');

        return redirect('/admin/extensions/{identifier}/settings')
            ->with('success', 'Settings saved successfully.');
    }
}
