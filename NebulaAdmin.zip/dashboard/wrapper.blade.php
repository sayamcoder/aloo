<!-- Nebula Quick Links Bar -->
<div id="nebula-quick-links">
    <div style="font-weight: 800; font-size: 0.9rem; color: #fff; margin-right: 10px;">
        NEBULA<span style="color: var(--nb-accent2);">SYSTEM</span>
    </div>
    <a href="/" class="nb-ql-item"><i class="fa fa-th-large"></i> Dashboard</a>
    <a href="/account" class="nb-ql-item"><i class="fa fa-user"></i> Account</a>
    <a href="/account/api" class="nb-ql-item"><i class="fa fa-key"></i> API Access</a>
    
    <div style="margin-left: auto; display: flex; align-items: center; gap: 15px;">
        <div id="nb-clock" style="font-family: monospace; color: var(--nb-accent2); font-size: 0.85rem; font-weight: 700;">
            00:00:00
        </div>
        <div class="nb-badge purple" style="font-size: 0.7rem; padding: 2px 8px; border-radius: 4px; background: rgba(108,99,255,0.2); color: #a78bfa; border: 1px solid rgba(108,99,255,0.3);">
            NEBULA v1.0
        </div>
    </div>
</div>

<script>
    // Update clock
    function updateNbClock() {
        const now = new Date();
        const timeStr = now.getHours().toString().padStart(2, '0') + ':' + 
                        now.getMinutes().toString().padStart(2, '0') + ':' + 
                        now.getSeconds().toString().padStart(2, '0');
        const clockEl = document.getElementById('nb-clock');
        if (clockEl) clockEl.textContent = timeStr;
    }
    setInterval(updateNbClock, 1000);
    updateNbClock();

    // Subtle parallax effect on background
    document.addEventListener('mousemove', (e) => {
        const moveX = (e.clientX - window.innerWidth / 2) * 0.01;
        const moveY = (e.clientY - window.innerHeight / 2) * 0.01;
        document.body.style.backgroundPosition = `${20 + moveX}% ${30 + moveY}%, ${80 - moveX}% ${70 - moveY}%`;
    });
</script>
