<?php

use Illuminate\Support\Facades\Route;

// Client routes for NebulaAdmin.
// Prefixed with /api/client/extensions/nebulaadmin/ by Blueprint.
