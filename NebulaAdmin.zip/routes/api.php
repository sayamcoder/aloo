<?php

use Illuminate\Support\Facades\Route;

// API routes for NebulaAdmin.
// Prefixed with /api/extensions/nebulaadmin/ by Blueprint.
