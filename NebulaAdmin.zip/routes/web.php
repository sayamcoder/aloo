<?php

use Illuminate\Support\Facades\Route;

// Web routes for NebulaAdmin.
// Prefixed with /extensions/nebulaadmin/ by Blueprint.
